package com.example.transition.transition

import android.graphics.Bitmap
import android.media.MediaCodec
import android.util.Log
import com.example.transition.EglCore
import java.nio.ByteBuffer

class FadeTransitionRenderer(
    private val mimeType: String,
    private val width: Int,
    private val height: Int,
    private val transcodingVO: TranscodingVO,
    private val spec: VideoTransitionSpec.Fade,
) {

    private val transitionEncoder = TransitionEncoder(mimeType, width, height, spec)
    private val eglCore = EglCore()
    private val encoder = transitionEncoder.createEncoder()
    private val surface = encoder.createInputSurface()
    private val eglSurface = EglSurfaceWrapper(eglCore, surface)

    private val TAG = "FadeTransitionRender"
    fun render(
        prevBitmap: Bitmap,
        nextBitmap: Bitmap,
    ): List<Pair<ByteBuffer, MediaCodec.BufferInfo>> {

        encoder.start()
        eglSurface.makeCurrent()

        val startTime = System.currentTimeMillis()
        val normalizer = GpuFrameNormalizer(width, height)

        val prevNorm = normalizer.normalize(prevBitmap, transcodingVO.rotation)
        val nextNorm = normalizer.normalize(nextBitmap, transcodingVO.rotation)

        val endTime = System.currentTimeMillis()
        Log.i(TAG, "normalize time = ${endTime - startTime} ms")
        val glRenderer = FadeGlRenderer(width, height)

        val tex1 = Texture2D(prevNorm.textureId)
        val tex2 = Texture2D(nextNorm.textureId)

        glRenderer.setTextures(tex1, tex2)


        val totalFrames = (spec.durationMs * spec.frameRate / 1000).toInt()
        val output = mutableListOf<Pair<ByteBuffer, MediaCodec.BufferInfo>>()
        val bufferInfo = MediaCodec.BufferInfo()

        repeat(totalFrames) { index ->
            val progress = index.toFloat() / totalFrames
            glRenderer.draw(progress)
            eglSurface.setPresentationTime(index * 1_000_000_000L / spec.frameRate)
            eglSurface.swapBuffers()
            transitionEncoder.drainEncoder(encoder, output, bufferInfo, false)
        }

        transitionEncoder.drainEncoder(encoder, output, bufferInfo, true)

        glRenderer.close()
        eglSurface.close()
        eglCore.close()
        encoder.stop()
        encoder.release()

        return output
    }
}


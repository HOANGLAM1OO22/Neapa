package com.example.transition.transition

import android.opengl.GLES20

class GlProgram(vertexSrc: String, fragmentSrc: String) : AutoCloseable {

    val programId: Int
    private var released = false

    init {
        val v = compile(GLES20.GL_VERTEX_SHADER, vertexSrc)
        val f = compile(GLES20.GL_FRAGMENT_SHADER, fragmentSrc)

        programId = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, v)
            GLES20.glAttachShader(it, f)
            GLES20.glLinkProgram(it)
        }
    }

    fun use() {
        GLES20.glUseProgram(programId)
    }

    private fun compile(type: Int, src: String): Int =
        GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, src)
            GLES20.glCompileShader(it)
        }

    override fun close() {
        if (released) return
        released = true
        GLES20.glDeleteProgram(programId)
    }

    protected fun finalize() { close() }
}

package com.example.transition.transition

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLUtils
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class GpuFrameNormalizer(
    private val targetW: Int,
    private val targetH: Int
) : AutoCloseable {

    // ===============================
    // Programs
    // ===============================
    private val rotateProgram = GlProgram(
        ROTATE_VERTEX,
        ROTATE_FRAGMENT
    )

    private val resizeProgram = GlProgram(
        RESIZE_VERTEX,
        RESIZE_FRAGMENT
    )

    // ===============================
    // Fullscreen quad
    // Texture coord đã FIX đúng cho Bitmap → GL
    // (KHÔNG cần flip trong shader nữa)
    // ===============================
    private val vertexData = floatArrayOf(
        // x, y,   u, v
        -1f, -1f, 0f, 0f,
        1f, -1f, 1f, 0f,
        -1f,  1f, 0f, 1f,
        1f,  1f, 1f, 1f
    )

    private val vertexBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(vertexData.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(vertexData)
                position(0)
            }

    // ============================================================
    // PUBLIC API
    // ============================================================
    fun normalize(src: Bitmap, rotation: Int): NormalizedTexture {

        // ---------- PASS 1: ROTATE ----------
        val (rotTex, rotW, rotH) = rotatePass(src, rotation)

        // ---------- PASS 2: RESIZE + CROP ----------
        val outTex = resizeCropPass(rotTex, rotW, rotH)

        GLES20.glDeleteTextures(1, intArrayOf(rotTex), 0)

        return NormalizedTexture(outTex, targetW, targetH)
    }

    // ============================================================
    // PASS 1: ROTATE (geometry correct)
    // ============================================================
    private fun rotatePass(
        src: Bitmap,
        rotation: Int
    ): Triple<Int, Int, Int> {

        val srcTex = createTextureFromBitmap(src)

        if (rotation % 360 == 0) {
            return Triple(srcTex, src.width, src.height)
        }

        val outW = if (rotation % 180 == 0) src.width else src.height
        val outH = if (rotation % 180 == 0) src.height else src.width

        val outTex = createEmptyTexture(outW, outH)
        val fbo = createFbo(outTex)

        GLES20.glViewport(0, 0, outW, outH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        rotateProgram.use()

        drawFullQuad(
            program = rotateProgram,
            textureId = srcTex,
            extraUniform = {
                GLES20.glUniform1i(
                    GLES20.glGetUniformLocation(
                        rotateProgram.programId, "uRotation"
                    ),
                    rotation
                )
            }
        )

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glDeleteFramebuffers(1, intArrayOf(fbo), 0)
        GLES20.glDeleteTextures(1, intArrayOf(srcTex), 0)

        return Triple(outTex, outW, outH)
    }

    // ============================================================
    // PASS 2: RESIZE + CENTER CROP
    // ============================================================
    private fun resizeCropPass(
        srcTex: Int,
        srcW: Int,
        srcH: Int
    ): Int {

        val scale = maxOf(
            targetW.toFloat() / srcW,
            targetH.toFloat() / srcH
        )

        val scaledW = srcW * scale
        val scaledH = srcH * scale

        val uScale = targetW / scaledW
        val vScale = targetH / scaledH
        val uOffset = (1f - uScale) * 0.5f
        val vOffset = (1f - vScale) * 0.5f

        val outTex = createEmptyTexture(targetW, targetH)
        val fbo = createFbo(outTex)

        GLES20.glViewport(0, 0, targetW, targetH)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)

        resizeProgram.use()

        drawFullQuad(
            program = resizeProgram,
            textureId = srcTex,
            extraUniform = {
                GLES20.glUniform2f(
                    GLES20.glGetUniformLocation(
                        resizeProgram.programId, "uScale"
                    ),
                    uScale, vScale
                )
                GLES20.glUniform2f(
                    GLES20.glGetUniformLocation(
                        resizeProgram.programId, "uOffset"
                    ),
                    uOffset, vOffset
                )
            }
        )

        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        GLES20.glDeleteFramebuffers(1, intArrayOf(fbo), 0)

        return outTex
    }

    // ============================================================
    // DRAW
    // ============================================================
    private fun drawFullQuad(
        program: GlProgram,
        textureId: Int,
        extraUniform: () -> Unit
    ) {
        val aPos = GLES20.glGetAttribLocation(program.programId, "aPosition")
        val aTex = GLES20.glGetAttribLocation(program.programId, "aTexCoord")

        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        vertexBuffer.position(2)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
        GLES20.glUniform1i(
            GLES20.glGetUniformLocation(program.programId, "uTexture"), 0
        )

        extraUniform()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)

        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aTex)
    }

    // ============================================================
    // GL UTILS
    // ============================================================
    private fun createTextureFromBitmap(bitmap: Bitmap): Int {
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
        return tex[0]
    }

    private fun createEmptyTexture(w: Int, h: Int): Int {
        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex[0])
        GLES20.glTexImage2D(
            GLES20.GL_TEXTURE_2D,
            0,
            GLES20.GL_RGBA,
            w,
            h,
            0,
            GLES20.GL_RGBA,
            GLES20.GL_UNSIGNED_BYTE,
            null
        )
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return tex[0]
    }

    private fun createFbo(tex: Int): Int {
        val fbo = IntArray(1)
        GLES20.glGenFramebuffers(1, fbo, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo[0])
        GLES20.glFramebufferTexture2D(
            GLES20.GL_FRAMEBUFFER,
            GLES20.GL_COLOR_ATTACHMENT0,
            GLES20.GL_TEXTURE_2D,
            tex,
            0
        )
        return fbo[0]
    }

    override fun close() {
        rotateProgram.close()
        resizeProgram.close()
    }

    // ============================================================
    // SHADERS (NO FLIP)
    // ============================================================
    companion object {

        const val ROTATE_VERTEX = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aTexCoord;
            }
        """

        const val ROTATE_FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTexture;
            uniform int uRotation;
            varying vec2 vTexCoord;

            vec2 rot(vec2 tc) {
                if (uRotation == 90) {
                    return vec2(tc.y, 1.0 - tc.x);
                } else if (uRotation == 180) {
                    return vec2(1.0 - tc.x, 1.0 - tc.y);
                } else if (uRotation == 270) {
                    return vec2(1.0 - tc.y, tc.x);
                }
                return tc;
            }

            void main() {
                gl_FragColor = texture2D(uTexture, rot(vTexCoord));
            }
        """

        const val RESIZE_VERTEX = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = aPosition;
                vTexCoord = aTexCoord;
            }
        """

        const val RESIZE_FRAGMENT = """
            precision mediump float;
            uniform sampler2D uTexture;
            uniform vec2 uScale;
            uniform vec2 uOffset;
            varying vec2 vTexCoord;

            void main() {
                vec2 tc = vTexCoord * uScale + uOffset;
//                tc.x = 1.0 - tc.x;
//                tc.y = 1.0 - tc.y;
                gl_FragColor = texture2D(uTexture, tc);
            }
        """
    }
}

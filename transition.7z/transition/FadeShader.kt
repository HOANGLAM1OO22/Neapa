package com.example.transition.transition


class FadeShader {

    companion object {
        val VERTEX_SHADER = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
//                gl_Position = aPosition;
                
                gl_Position = vec4(-aPosition.x, -aPosition.y, aPosition.z, aPosition.w);

                vTexCoord = aTexCoord;
            }
        """

        val FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTex1;
            uniform sampler2D uTex2;
            uniform float uProgress;
            varying vec2 vTexCoord;
            void main() {
                vec4 c1 = texture2D(uTex1, vTexCoord);
                vec4 c2 = texture2D(uTex2, vTexCoord);
                gl_FragColor = mix(c1, c2, uProgress);
            }
        """
    }
}


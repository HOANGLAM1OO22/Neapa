package com.example.transition.transition

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.core.graphics.scale
import kotlin.math.roundToInt


object FrameNormalizer {

    /**
     * Normalize bitmap to match video track pixel orientation.
     */
    fun normalize(
        src: Bitmap,
        rotation: Int,
        targetW: Int,
        targetH: Int
    ): Bitmap {
        val rotated = rotate(src, rotation)
        val srcWidth = rotated.width
        val srcHeight = rotated.height

        val scale = maxOf(
            targetW.toFloat() / srcWidth,
            targetH.toFloat() / srcHeight
        )

        val scaledW = (srcWidth * scale).roundToInt()
        val scaledH = (srcHeight * scale).roundToInt()

        val scaled = rotated.scale(scaledW, scaledH)

        val cropX = ((scaledW - targetW) / 2).coerceAtLeast(0)
        val cropY = ((scaledH - targetH) / 2).coerceAtLeast(0)

        return Bitmap.createBitmap(scaled, cropX, cropY, targetW, targetH)
    }

    private fun rotate(src: Bitmap, rotation: Int): Bitmap {
        if (rotation == 0) return src
        val matrix = Matrix().apply {
            postRotate(-rotation.toFloat())
        }
        return Bitmap.createBitmap(
            src, 0, 0, src.width, src.height, matrix, true
        )
    }
}

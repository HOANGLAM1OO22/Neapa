package com.example.transition.transition

import android.opengl.GLES20

class NormalizedTexture(
    val textureId: Int,
    val width: Int,
    val height: Int
) : AutoCloseable {

    override fun close() {
        GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
    }
}

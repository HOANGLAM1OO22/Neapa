package com.example.transition.transition

import android.media.MediaCodec
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.util.Log
import java.io.File
import java.nio.ByteBuffer
class VideoTransitionExecutor {

    private val TAG = "VideoTransitionExecutor"

    fun execute(
        prev: File,
        next: File,
        transcodingVO: TranscodingVO,
        spec: VideoTransitionSpec.Fade
    ): List<Pair<ByteBuffer, MediaCodec.BufferInfo>> {

        val start = System.currentTimeMillis()

        val retriever = MediaMetadataRetriever()

        // ---------- PREV ----------
        retriever.setDataSource(prev.absolutePath)
        val prevBmp = retriever.getFrameAtTime(0)
            ?: error("Cannot get frame from prev video")

        // ---------- NEXT ----------
        retriever.setDataSource(next.absolutePath)
        val nextBmp = retriever.getFrameAtTime(0)
            ?: error("Cannot get frame from next video")

        retriever.release()

        val extractDone = System.currentTimeMillis()
        Log.i(TAG, "extract frame time=${extractDone - start} ms")

        val width = transcodingVO.width
        val height = transcodingVO.height
        val rotation = transcodingVO.rotation

        Log.i(TAG, "video info: ${width}x${height}, rotation=$rotation")

        val renderer = FadeTransitionRenderer(
            transcodingVO.mimeType,
            width,
            height,
            transcodingVO,
            spec
        )

        val samples = renderer.render(
            prevBitmap = prevBmp,
            nextBitmap = nextBmp
        )

        Log.i(TAG, "samples=${samples.size}")
        Log.i(TAG, "elapsed=${System.currentTimeMillis() - start} ms")

        return samples
    }
}


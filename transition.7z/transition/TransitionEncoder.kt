package com.example.transition.transition

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import java.nio.ByteBuffer

class TransitionEncoder(
    private val mimeType: String,
    private val width: Int,
    private val height: Int,
    private val spec: VideoTransitionSpec.Fade
) {

    fun createEncoder(): MediaCodec {
        val format = MediaFormat.createVideoFormat(
            mimeType, width, height
        ).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
            setInteger(MediaFormat.KEY_BIT_RATE, 1_000_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, spec.frameRate)
            setFloat(MediaFormat.KEY_I_FRAME_INTERVAL, 0.5f)
        }

        return MediaCodec.createEncoderByType(mimeType).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
    }

    fun drainEncoder(
        encoder: MediaCodec,
        out: MutableList<Pair<ByteBuffer, MediaCodec.BufferInfo>>,
        info: MediaCodec.BufferInfo,
        eos: Boolean
    ) {
        if (eos) encoder.signalEndOfInputStream()

        while (true) {
            val index = encoder.dequeueOutputBuffer(info, 10_000)

            when {
                index >= 0 -> {
                    val buf = encoder.getOutputBuffer(index)!!

                    val copyBuf = ByteBuffer.allocateDirect(info.size)
                    buf.limit(info.offset + info.size)
                    buf.position(info.offset)
                    copyBuf.put(buf).flip()

                    val flag = info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv()
                    out += copyBuf to MediaCodec.BufferInfo().apply {
                        set(info.offset, info.size, info.presentationTimeUs, flag)
                    }
                    encoder.releaseOutputBuffer(index, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }

                index == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    // ignore – expected once
                }

                index == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!eos) break
                }
            }
        }
    }
}


package com.example.transition.transition

import android.opengl.GLES20
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class FadeGlRenderer(width: Int, height: Int) : AutoCloseable {
    private var released = false
    private val vertexData = floatArrayOf(
        -1f, -1f, 0f, 1f,
        1f, -1f, 1f, 1f,
        -1f,  1f, 0f, 0f,
        1f,  1f, 1f, 0f
    )

    private val vertexBuffer: FloatBuffer =
        ByteBuffer.allocateDirect(vertexData.size * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(vertexData)
                position(0)
            }

    private val program = GlProgram(FadeShader.VERTEX_SHADER, FadeShader.FRAGMENT_SHADER)
    private lateinit var texFrom: Texture2D
    private lateinit var texTo: Texture2D

    private val aPos = GLES20.glGetAttribLocation(program.programId, "aPosition")

    private val aTex = GLES20.glGetAttribLocation(program.programId, "aTexCoord")

    private val uTex1 = GLES20.glGetUniformLocation(program.programId, "uTex1")

    private val uTex2 = GLES20.glGetUniformLocation(program.programId, "uTex2")

    private val uProgress = GLES20.glGetUniformLocation(program.programId, "uProgress")

    init {
        GLES20.glViewport(0, 0, width, height)
        GLES20.glClearColor(0f, 0f, 0f, 1f)
    }

    fun setTextures(from: Texture2D, to: Texture2D) {
        texFrom = from
        texTo = to
    }

    fun draw(progress: Float) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        program.use()

        vertexBuffer.position(0)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        vertexBuffer.position(2)
        GLES20.glEnableVertexAttribArray(aTex)
        GLES20.glVertexAttribPointer(aTex, 2, GLES20.GL_FLOAT, false, 16, vertexBuffer)

        texFrom.bind(0)
        GLES20.glUniform1i(uTex1, 0)

        texTo.bind(1)
        GLES20.glUniform1i(uTex2, 1)

        GLES20.glUniform1f(uProgress, progress)

        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    override fun close() {
        if (released) return
        released = true
        texFrom.close()
        texTo.close()
        program.close()
    }

    protected fun finalize() { close() }
}



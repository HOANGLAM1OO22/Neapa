package com.example.transition.transition

import kotlin.math.cos
import kotlin.math.sin

object TexMatrix {

    fun setIdentity(m: FloatArray) {
        for (i in m.indices) m[i] = 0f
        m[0] = 1f
        m[4] = 1f
        m[8] = 1f
    }

    fun rotate(m: FloatArray, deg: Int) {
        val rad = Math.toRadians(deg.toDouble())
        val c = cos(rad).toFloat()
        val s = sin(rad).toFloat()

        val r = floatArrayOf(
            c, -s, 0f,
            s,  c, 0f,
            0f, 0f, 1f
        )
        multiply(m, r)
    }

    fun scale(m: FloatArray, sx: Float, sy: Float) {
        val s = floatArrayOf(
            sx, 0f, 0f,
            0f, sy, 0f,
            0f, 0f, 1f
        )
        multiply(m, s)
    }

    fun translate(m: FloatArray, tx: Float, ty: Float) {
        val t = floatArrayOf(
            1f, 0f, tx,
            0f, 1f, ty,
            0f, 0f, 1f
        )
        multiply(m, t)
    }

    private fun multiply(a: FloatArray, b: FloatArray) {
        val r = FloatArray(9)
        for (i in 0..2)
            for (j in 0..2)
                r[i * 3 + j] =
                    a[i * 3] * b[j] +
                            a[i * 3 + 1] * b[j + 3] +
                            a[i * 3 + 2] * b[j + 6]
        System.arraycopy(r, 0, a, 0, 9)
    }
}

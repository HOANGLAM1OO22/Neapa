
package com.example.transition.transition

import android.graphics.Bitmap
import android.opengl.GLES20
import android.opengl.GLUtils

class Texture2D : AutoCloseable {

    val id: Int
    private var released = false
    private val ownsTexture: Boolean

    /** Constructor dùng khi upload từ Bitmap (ownership = true) */
    constructor(bitmap: Bitmap) {
        ownsTexture = true

        val tex = IntArray(1)
        GLES20.glGenTextures(1, tex, 0)
        id = tex[0]

        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)

        GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
    }

    /** Constructor dùng khi WRAP textureId có sẵn (ownership = false) */
    constructor(textureId: Int) {
        ownsTexture = false
        id = textureId
    }

    fun bind(unit: Int) {
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0 + unit)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, id)
    }

    override fun close() {
        if (released) return
        released = true

        if (ownsTexture) {
            GLES20.glDeleteTextures(1, intArrayOf(id), 0)
        }
    }

    protected fun finalize() {
        close()
    }
}


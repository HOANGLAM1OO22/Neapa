package com.example.transition.transition

import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.view.Surface
import com.example.transition.EglCore

class EglSurfaceWrapper(
    private val eglCore: EglCore,
    private val surface: Surface
) : AutoCloseable {

    private var eglSurface: EGLSurface = EGL14.EGL_NO_SURFACE
    private var closed = false

    init {
        createEglSurface()
    }

    private fun createEglSurface() {
        val surfaceAttribs = intArrayOf(
            EGL14.EGL_NONE
        )

        eglSurface = EGL14.eglCreateWindowSurface(
            eglCore.eglDisplay,
            eglCore.eglConfig,
            surface,
            surfaceAttribs,
            0
        )

        require(eglSurface != EGL14.EGL_NO_SURFACE) {
            "Failed to create EGL window surface"
        }
    }

    fun makeCurrent() {
        require(
            EGL14.eglMakeCurrent(
                eglCore.eglDisplay,
                eglSurface,
                eglSurface,
                eglCore.eglContext
            )
        ) {
            "eglMakeCurrent failed"
        }
    }

    fun swapBuffers(): Boolean {
        return EGL14.eglSwapBuffers(
            eglCore.eglDisplay,
            eglSurface
        )
    }

    fun setPresentationTime(nsecs: Long) {
        EGLExt.eglPresentationTimeANDROID(
            eglCore.eglDisplay,
            eglSurface,
            nsecs
        )
    }

    override fun close() {
        if (closed) return
        closed = true
        if (eglSurface != EGL14.EGL_NO_SURFACE) {
            EGL14.eglDestroySurface(
                eglCore.eglDisplay,
                eglSurface
            )
            eglSurface = EGL14.EGL_NO_SURFACE
        }
        surface.release()
    }

    protected fun finalize() { close() }
}


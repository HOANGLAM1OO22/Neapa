package com.example.transition.transition

import android.media.MediaFormat

class TranscodingVO {
    var width: Int = 0
    var height: Int = 0
    var rotation: Int = 0
    var mimeType: String = MediaFormat.MIMETYPE_VIDEO_AVC

    override fun toString(): String {
        return "transcodingVO= w=$width, h=$height, r=$rotation, mimeType=$mimeType"
    }
}

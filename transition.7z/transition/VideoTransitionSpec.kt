package com.example.transition.transition

sealed class VideoTransitionSpec {
    data class Fade(
        val durationMs: Long,
        val frameRate: Int
    ) : VideoTransitionSpec()
}


package com.example.transition.transition

object NormalizeFadeShader {

    const val VERTEX = """
            attribute vec4 aPosition;
            attribute vec2 aTexCoord;

            uniform int uRotation;   // 0, 90, 180, 270
            uniform vec2 uScale;
            uniform vec2 uOffset;
            
            varying vec2 vTexCoord;
            
            vec2 rotateTex(vec2 tc) {
                if (uRotation == 90) {
                    return vec2(tc.y, 1.0 - tc.x);
                } else if (uRotation == 180) {
                    return vec2(1.0 - tc.x, 1.0 - tc.y);
                } else if (uRotation == 270) {
                    return vec2(1.0 - tc.y, tc.x);
                }
                return tc;
            }
            
            void main() {
                gl_Position = aPosition;
            
                vec2 tc = aTexCoord;
            
                tc.x = 1.0 - tc.x;
            
                tc = rotateTex(tc);
            
                // center-crop
                tc = tc * uScale + uOffset;
            
                vTexCoord = tc;
            }

    """

    const val FRAGMENT = """
        precision mediump float;
        uniform sampler2D uTexture;
        varying vec2 vTexCoord;

        void main() {
            gl_FragColor = texture2D(uTexture, vTexCoord);
        }
    """
}
